import pytest
import uuid
from flask import url_for
from flask_login import login_user
from app.models import Review, Course, User
from datetime import datetime

def test_reviews_page_unauthenticated(client, test_data):
    """Test GET /courses/<course_id>/reviews without authentication"""
    course_id = test_data["course_id"]
    response = client.get(f"/courses/{course_id}/reviews")
    
    assert response.status_code == 200
    assert b"reviews.html" not in response.data
    assert response.request.path == f"/courses/{course_id}/reviews"

def test_reviews_page_authenticated(client, test_data, authenticated_user):
    """Test GET /courses/<course_id>/reviews with authentication"""
    user = authenticated_user
    course_id = test_data["course_id"]
    response = client.get(f"/courses/{course_id}/reviews")
    
    assert response.status_code == 200
    assert b"Great course!" in response.data
    assert b"Average course" in response.data
    assert b"Poor course" in response.data
    assert response.data.find(b"Poor course") < response.data.find(b"Average course")
    assert response.data.find(b"Average course") < response.data.find(b"Great course")

def test_reviews_page_with_sorting(client, test_data):
    """Test GET /courses/<course_id>/reviews with sorting parameters"""
    course_id = test_data["course_id"]
    
    response_positive = client.get(f"/courses/{course_id}/reviews?sort_by=positive")
    assert response_positive.status_code == 200
    assert response_positive.data.find(b"Great course") < response_positive.data.find(b"Average course")
    assert response_positive.data.find(b"Average course") < response_positive.data.find(b"Poor course")
    
    response_negative = client.get(f"/courses/{course_id}/reviews?sort_by=negative")
    assert response_negative.status_code == 200
    assert response_negative.data.find(b"Poor course") < response_negative.data.find(b"Average course")
    assert response_negative.data.find(b"Average course") < response_negative.data.find(b"Great course")

def test_reviews_page_pagination(client, test_data, db_session):
    """Test GET /courses/<course_id>/reviews with pagination"""
    course_id = test_data["course_id"]
    # Create 10 additional reviews with different timestamps
    additional_reviews = [
        Review(
            rating=4,
            text=f"Review {i}",
            course_id=course_id,
            user_id=test_data["user_id"],
            created_at=datetime(2025, 1, 3 + i)  # Spread out the dates
        ) for i in range(1, 11)
    ]
    db_session.session.add_all(additional_reviews)
    db_session.session.commit()
    
    response = client.get(f"/courses/{course_id}/reviews?page=1&")
    assert response.status_code == 200
    
    for i in reversed(range(1, 11)):
        assert f"Review {i}" in response.text

    response_page2 = client.get(f"/courses/{course_id}/reviews?page=2")
    assert response_page2.status_code == 200
    assert b"Poor course" in response_page2.data
    assert b"Average course" in response_page2.data
    assert b"Great course!" in response_page2.data
    
def test_create_review_success(client, db_session, test_data, authenticated_user):
    """Test successful creation of a review"""
    user = authenticated_user
    course_id = test_data["course_id"]
    
    # Data for the new review
    review_data = {
        "rating": 4,
        "text": "This is a great course!"
    }

    headers = {
        "Referer": f"http://localhost/courses/{course_id}"  # Имитируем referrer
    }
    
    response = client.post(f"/courses/{course_id}/reviews/create", 
                           data=review_data, 
                           headers=headers,
                           follow_redirects=True)
    
    assert response.status_code == 200
    
    review = db_session.session.query(Review).filter_by(
        course_id=course_id,
        user_id=user.id,
        text=review_data["text"]
    ).first()
    
    assert review.rating == review_data["rating"]
    assert review.text == review_data["text"]
    assert review.course_id == course_id
    assert review.user_id == user.id
    
    course = db_session.session.query(Course).get(course_id)
    assert course.rating_sum == (1+5+3+4)
    assert course.rating_num == 4

def test_create_review_with_empty_text(test_data, db_session, client, authenticated_user):
    """Test POST /courses/<course_id>/reviews/create with empty text"""
    user = authenticated_user
    course_id = test_data["course_id"]
    
    headers = {
        "Referer": f"http://localhost/courses/{course_id}"  # Имитируем referrer
    }

    response = client.post(
        f"/courses/{course_id}/reviews/create",
        headers=headers,
        data={"rating": 4, "text": ""},
        follow_redirects=True
    )
    
    assert response.status_code == 200
    assert "Текст отзыва не может быть пустым".encode() in response.data
    
    reviews = db_session.session.query(Review).filter_by(course_id=course_id).all()
    assert len(reviews) == 3

def test_create_review_with_duplicate(test_data, db_session, review_repo, client, authenticated_user_with_review):
    """Test POST /courses/<course_id>/reviews/create with duplicate review"""
    user = authenticated_user_with_review
    course_id = test_data["course_id"]
    
    headers = {
        "Referer": f"http://localhost/courses/{course_id}"  # Имитируем referrer
    }

    response = client.post(
        f"/courses/{course_id}/reviews/create",
        headers=headers,
        data={"rating": 4, "text": "Duplicate review"},
        follow_redirects=True
    )
    
    assert response.status_code == 200
    assert "Вы уже оставляли отзыв на этот курс".encode() in response.data
    
    reviews = db_session.session.query(Review).filter_by(course_id=course_id).all()
    assert len(reviews) == 3

def test_delete_review_with_success(test_data, db_session, client, authenticated_user_with_review, review_repo):
    """Test POST /reviews/<review_id>/delete by review owner"""
    user = authenticated_user_with_review
    course_id = test_data["course_id"]
    
    # review = db_session.session.query(Review).filter_by(course_id=course_id, user_id=user.id).first()
    
    review = review_repo.get_user_review_for_course(user.id, course_id)

    headers = {
        "Referer": f"http://localhost/courses/{course_id}"  # Имитируем referrer
    }

    response = client.post(
        f"/courses/reviews/{review.id}/delete",
        follow_redirects=True,
        headers=headers
    )
    
    assert response.status_code == 200
    assert "Отзыв успешно удалён".encode() in response.data
    
    deleted_review = db_session.session.get(Review, review.id)
    assert deleted_review is None
    
    course = db_session.session.get(Course, course_id)
    assert course.rating_num == 2
    assert course.rating_sum == 8

def test_delete_review_as_not_owner(test_data, db_session, client, authenticated_user, review_repo):
    """Test POST /reviews/<review_id>/delete by non-owner"""
    user = authenticated_user
    course_id = test_data["course_id"]

    review = review_repo.get_latest_reviews_by_course_id(course_id)[0]
    
    course = db_session.session.get(Course, course_id)
    old_rating_num = course.rating_num
    old_rating_sum = course.rating_sum

    headers = {
        "Referer": f"http://localhost/courses/{course_id}"  # Имитируем referrer
    }

    response = client.post(
        f"/courses/reviews/{review.id}/delete",
        headers=headers,
        follow_redirects=True
    )
    
    assert response.status_code == 200
    
    course = db_session.session.get(Course, course_id)
    assert course.rating_num == old_rating_num
    assert course.rating_sum == old_rating_sum

def test_delete_review_not_exists(test_data, client, authenticated_user):
    user = authenticated_user
    course_id = test_data["course_id"]

    headers = {
        "Referer": f"http://localhost/courses/{course_id}"  # Имитируем referrer
    }

    response = client.post(
        f"/courses/reviews/999/delete",
        headers=headers,
        follow_redirects=True
    )
    
    assert response.status_code == 200
    assert "Не удалось удалить отзыв".encode() in response.data