from app.models import Review, Course, User
import uuid


def test_get_latest_reviews_by_course_id(review_repo, test_data):
    """Test getting latest reviews for a course"""
    reviews = review_repo.get_latest_reviews_by_course_id(test_data["course_id"])
    
    assert len(reviews) <= 5
    assert len(reviews) == 3  # We created 3 reviews
    assert reviews[0].rating == 1  # Latest review should be first (2025-01-03)
    assert reviews[1].rating == 3
    assert reviews[2].rating == 5

def test_get_paginated_reviews_newest(review_repo, test_data):
    """Test paginated reviews with newest sort"""
    pagination = review_repo.get_paginated_reviews(test_data["course_id"], page=1, per_page=2, sort_by='newest')
    
    assert pagination.total == 3
    assert len(pagination.items) == 2
    assert pagination.items[0].rating == 1  # Latest first
    assert pagination.items[1].rating == 3

def test_get_paginated_reviews_positive(review_repo, test_data):
    """Test paginated reviews with positive sort"""
    pagination = review_repo.get_paginated_reviews(test_data["course_id"], page=1, per_page=2, sort_by='positive')
    
    assert pagination.total == 3
    assert len(pagination.items) == 2
    assert pagination.items[0].rating == 5  # Highest rating first
    assert pagination.items[1].rating == 3

def test_get_paginated_reviews_negative(review_repo, test_data):
    """Test paginated reviews with negative sort"""
    pagination = review_repo.get_paginated_reviews(test_data["course_id"], page=1, per_page=2, sort_by='negative')
    
    assert pagination.total == 3
    assert len(pagination.items) == 2
    assert pagination.items[0].rating == 1  # Lowest rating first
    assert pagination.items[1].rating == 3

def test_get_user_review_for_course_exists(review_repo, test_data):
    """Test getting existing user review for a course"""
    review = review_repo.get_user_review_for_course(test_data["user_id"], test_data["course_id"])
    
    assert review is not None
    assert review.user_id == test_data["user_id"]
    assert review.course_id == test_data["course_id"]

def test_get_user_review_for_course_not_exists(review_repo, test_data):
    """Test getting non-existent user review"""
    review = review_repo.get_user_review_for_course(999, test_data["course_id"])
    
    assert review is None

def test_create_review_success(review_repo, test_data, db_session):
    """Test creating a new review with a new user"""
    # Create a new user to avoid duplicate reviews
    new_user = User(
        first_name="Test",
        last_name="User",
        login=f"testuser_{uuid.uuid4().hex[:8]}"
    )
    new_user.set_password("password")
    db_session.session.add(new_user)
    db_session.session.commit()
    
    # Create new review with new user
    new_review = review_repo.create_review(
        user_id=new_user.id,
        course_id=test_data["course_id"],
        rating=4,
        text="New review"
    )
    
    assert new_review is not None
    assert new_review.rating == 4
    assert new_review.text == "New review"
    
    # Check course rating update
    course = db_session.session.get(Course, test_data["course_id"])
    assert course.rating_num == 4  # Original 3 + new 1
    assert course.rating_sum == 13  # 5 + 3 + 1 + 4

def test_create_review_duplicate(review_repo, test_data):
    """Test creating duplicate review"""
    review = review_repo.create_review(
        user_id=test_data["user_id"],
        course_id=test_data["course_id"],
        rating=4,
        text="Duplicate review"
    )
    
    assert review is None
    
    # Verify course ratings unchanged
    course = review_repo.db.session.get(Course, test_data["course_id"])
    assert course.rating_num == 3
    assert course.rating_sum == 9  # 5 + 3 + 1

def test_delete_review_success(review_repo, test_data):
    """Test deleting own review"""
    # Get a review to delete
    review = review_repo.get_user_review_for_course(test_data["user_id"], test_data["course_id"])
    
    result = review_repo.delete_review(review.id, test_data["user_id"])
    
    assert result is True
    
    # Verify review is deleted
    deleted_review = review_repo.db.session.get(Review, review.id)
    assert deleted_review is None
    
    # Check course rating update
    course = review_repo.db.session.get(Course, test_data["course_id"])
    assert course.rating_num == 2
    assert course.rating_sum == 8  # 5 + 3 (1 was deleted)

def test_delete_review_not_owner(review_repo, test_data):
    """Test deleting review as non-owner"""
    review = review_repo.get_user_review_for_course(test_data["user_id"], test_data["course_id"])
    
    result = review_repo.delete_review(review.id, 999)
    
    assert result is False
    
    # Verify review still exists
    existing_review = review_repo.db.session.get(Review, review.id)
    assert existing_review is not None
    
    # Verify course ratings unchanged
    course = review_repo.db.session.get(Course, test_data["course_id"])
    assert course.rating_num == 3
    assert course.rating_sum == 9

def test_delete_review_not_exists(review_repo, test_data):
    """Test deleting non-existent review"""
    result = review_repo.delete_review(999, test_data["user_id"])
    
    assert result is False