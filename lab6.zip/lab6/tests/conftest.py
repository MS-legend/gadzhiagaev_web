import pytest
import uuid
from datetime import datetime
from flask_login import login_user
from app import create_app
from app.models import db, Review, Course, User, Category, Image
from app.repositories.review_repository import ReviewRepository

@pytest.fixture
def app():
    """Create a test Flask app with MySQL database"""
    app = create_app({
        'SQLALCHEMY_DATABASE_URI': 'mysql+mysqlconnector://root:12345@localhost/lab6_test',
        'TESTING': True,
        'SECRET_KEY': 'test-secret-key',
        'WTF_CSRF_ENABLED': False
    })
    with app.app_context():
        db.create_all()
        yield app
        db.drop_all()

@pytest.fixture
def db_session(app):
    """Provide the Flask-SQLAlchemy db object"""
    with app.app_context():
        yield db

@pytest.fixture
def review_repo(db_session):
    """Create ReviewRepository instance with Flask-SQLAlchemy db"""
    return ReviewRepository(db_session)

@pytest.fixture
def client(app):
    """Create a test client for the Flask app"""
    return app.test_client()

@pytest.fixture
def authenticated_user_with_review(app, db_session, test_data):
    """Create and authenticate a test user"""
    with app.test_request_context():
        user = db_session.session.query(User).get(test_data['user_id'])
        login_user(user)
        yield user

@pytest.fixture
def authenticated_user(app, db_session):
    """Create and authenticate a new test user"""
    with app.app_context():
        # Create a new user with unique login
        unique_login = f"testuser_{uuid.uuid4().hex[:8]}"
        user = User(
            first_name="Test",
            last_name="User",
            login=unique_login
        )
        user.set_password("password")
        db_session.session.add(user)
        db_session.session.commit()
        
        with app.test_request_context():
            login_user(user)
            yield user

@pytest.fixture
def test_data(app, db_session):
    """Create test data for reviews"""
    with app.app_context():
        # Clear all relevant tables to ensure clean state
        db_session.session.query(Review).delete()
        db_session.session.query(Course).delete()
        db_session.session.query(User).delete()
        db_session.session.query(Category).delete()
        db_session.session.query(Image).delete()
        db_session.session.commit()
        
        # Create test user with unique login
        unique_login = f"johndoe_{uuid.uuid4().hex[:8]}"
        user = User(
            first_name="John",
            last_name="Doe",
            login=unique_login
        )
        user.set_password("password")
        db_session.session.add(user)
        
        # Create test category
        category = Category(name="Test Category")
        db_session.session.add(category)
        
        # Create test image
        image = Image(
            id=1,  # Числовой ID
            file_name="test.jpg",
            mime_type="image/jpeg",
            md5_hash="test_hash"
        )
        db_session.session.add(image)
        
        # Create test course
        course = Course(
            name="Test Course",
            short_desc="Short description",
            full_desc="Full description",
            category_id=1,
            author_id=1,
            background_image_id=1,
            rating_sum=0,
            rating_num=0
        )
        db_session.session.add(course)
        
        db_session.session.commit()
        
        # Create multiple reviews
        reviews = [
            Review(
                rating=1,
                text="Poor course",
                course_id=1,
                user_id=1,
                created_at=datetime(2025, 1, 3)
            ),
            Review(
                rating=5,
                text="Great course!",
                course_id=1,
                user_id=1,
                created_at=datetime(2025, 1, 1)
            ),
            Review(
                rating=3,
                text="Average course",
                course_id=1,
                user_id=1,
                created_at=datetime(2025, 1, 2)
            )
        ]
        db_session.session.add_all(reviews)
        
        # Update course rating
        course.rating_sum = sum(review.rating for review in reviews)
        course.rating_num = len(reviews)
        
        db_session.session.commit()
        
        return {"user_id": 1, "course_id": 1, "user_login": unique_login}