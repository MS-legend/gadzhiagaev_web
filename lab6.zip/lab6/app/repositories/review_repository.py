from app.models import Review, Course
from sqlalchemy import desc, asc

class ReviewRepository:
    def __init__(self, db):
        self.db = db

    def get_latest_reviews_by_course_id(self, course_id):
        return (
            self.db.session.query(Review)
            .filter_by(course_id=course_id)
            .order_by(desc(Review.created_at))
            .limit(5)
            .all()
        )

    def get_paginated_reviews(self, course_id, page=1, per_page=10, sort_by='newest'):
        query = self.db.session.query(Review).filter_by(course_id=course_id)
        
        # Применяем сортировку
        if sort_by == 'positive':
            query = query.order_by(desc(Review.rating), desc(Review.created_at))
        elif sort_by == 'negative':
            query = query.order_by(asc(Review.rating), desc(Review.created_at))
        else:  # newest (default)
            query = query.order_by(desc(Review.created_at))
            
        return query.paginate(page=page, per_page=per_page, error_out=False)
    
    def get_user_review_for_course(self, user_id, course_id):
        return self.db.session.query(Review).filter_by(
            user_id=user_id,
            course_id=course_id
        ).first()

    def create_review(self, user_id, course_id, rating, text):
        # Проверяем, есть ли уже отзыв
        existing_review = self.get_user_review_for_course(user_id, course_id)
        if existing_review:
            return None  # или можно выбрасывать исключение

        # Создаем новый отзыв
        review = Review(
            user_id=user_id,
            course_id=course_id,
            rating=rating,
            text=text
        )
        self.db.session.add(review)
        
        # Обновляем рейтинг курса
        course = self.db.session.get(Course, course_id)
        course.rating_sum += rating
        course.rating_num += 1
        
        self.db.session.commit()
        return review
    
    def delete_review(self, review_id, user_id):
        review = self.db.session.get(Review, review_id)
        
        if not review or review.user_id != user_id:
            return False  # Отзыв не найден или пользователь не автор
        
        # Получаем курс перед удалением
        course = review.course
        
        # Удаляем отзыв
        self.db.session.delete(review)
        
        # Обновляем рейтинг курса
        course.rating_sum -= review.rating
        course.rating_num -= 1
        
        self.db.session.commit()
        return True